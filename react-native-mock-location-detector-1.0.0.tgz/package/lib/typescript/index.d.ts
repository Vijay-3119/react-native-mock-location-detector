import { DetectionEvent, DetectionResult, MonitoringOptions } from './types';
/**
 * Perform a fast one-shot boolean check to determine if the location is mocked.
 */
export declare function isMockLocation(): Promise<boolean>;
/**
 * Perform a comprehensive one-shot detection check returning confidence score and full reason breakdown.
 */
export declare function getDetectionResult(options?: MonitoringOptions): Promise<DetectionResult>;
/**
 * Start periodic native monitoring for location mock updates.
 */
export declare function startMonitoring(options?: MonitoringOptions): Promise<boolean>;
/**
 * Stop continuous native monitoring.
 */
export declare function stopMonitoring(): Promise<boolean>;
/**
 * Subscribe to continuous monitoring events emitted from the native module.
 */
export declare function addListener(event: DetectionEvent | string, listener: (result: DetectionResult) => void): import("react-native").EmitterSubscription;
/**
 * Custom React Hook to continuously monitor mock location detection state.
 *
 * @param options Optional monitoring interval and confidence threshold configurations.
 * @returns DetectionResult state or null while initial check is resolving.
 */
export declare function useMockLocationDetector(options?: MonitoringOptions): DetectionResult | null;
export * from './types';
