import { DetectionResult, MonitoringOptions } from '../types';
/**
 * Custom React Hook to continuously monitor mock location detection state.
 *
 * @param options Optional monitoring interval and confidence threshold configurations.
 * @returns DetectionResult state or null while initial check is resolving.
 */
export declare function useMockLocationDetector(options?: MonitoringOptions): DetectionResult | null;
